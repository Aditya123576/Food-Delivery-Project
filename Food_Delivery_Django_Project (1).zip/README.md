# Food Delivery Website

A BCA-level food delivery web application built with Python, Django, SQLite, HTML, CSS and JavaScript.

## Features
- User registration/login/logout
- Restaurant and food listing
- Category filtering
- Food details
- Add to cart, quantity update and remove
- Checkout and order placement
- Order history
- Admin dashboard through Django admin
- Responsive UI

## Setup
```bash
python -m venv venv
# Windows
venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Open http://127.0.0.1:8000/

Admin: http://127.0.0.1:8000/admin/

## Demo data
Run:
```bash
python manage.py seed_data
```
Then open the website.

## GitHub
Create a new GitHub repository, then:
```bash
git init
git add .
git commit -m "Initial food delivery project"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/food-delivery-django.git
git push -u origin main
```
