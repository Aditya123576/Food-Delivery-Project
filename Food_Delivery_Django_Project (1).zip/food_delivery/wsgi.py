import os
from django.core.wsgi import get_wsgi_application
os.environ.setdefault("DJANGO_SETTINGS_MODULE","food_delivery.settings")
application = get_wsgi_application()
