from django.core.management.base import BaseCommand
from orders.models import Category, Restaurant, Food
class Command(BaseCommand):
    help="Create demo restaurants and food"
    def handle(self,*args,**kwargs):
        cats={}
        for n in ["Pizza","Burger","Indian","Chinese","Desserts"]:
            cats[n],_=Category.objects.get_or_create(name=n)
        data=[
            ("Pizza Palace","Italian",4.5,30,"Pizza","Margherita Pizza","Classic cheese pizza",249),
            ("Burger Hub","Fast Food",4.3,25,"Burger","Classic Burger","Crispy patty burger",179),
            ("Spice Kitchen","North Indian",4.6,35,"Indian","Paneer Butter Masala","Rich creamy paneer curry",299),
            ("Dragon Bowl","Chinese",4.2,30,"Chinese","Veg Hakka Noodles","Wok-tossed noodles",199),
            ("Sweet Treats","Desserts",4.4,20,"Desserts","Chocolate Brownie","Warm chocolate brownie",149),
        ]
        for rname,cuisine,rating,time,cat,name,desc,price in data:
            r,_=Restaurant.objects.get_or_create(name=rname,defaults={"cuisine":cuisine,"rating":rating,"delivery_time":time})
            Food.objects.get_or_create(restaurant=r,name=name,defaults={"category":cats[cat],"description":desc,"price":price})
        self.stdout.write(self.style.SUCCESS("Demo data created successfully."))
