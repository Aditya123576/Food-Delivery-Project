from django.db import models
from django.contrib.auth.models import User

class Category(models.Model):
    name = models.CharField(max_length=100)
    def __str__(self): return self.name

class Restaurant(models.Model):
    name = models.CharField(max_length=150)
    cuisine = models.CharField(max_length=150)
    rating = models.DecimalField(max_digits=2, decimal_places=1, default=4.0)
    delivery_time = models.PositiveIntegerField(default=30)
    image = models.URLField(blank=True)
    def __str__(self): return self.name

class Food(models.Model):
    restaurant = models.ForeignKey(Restaurant, on_delete=models.CASCADE, related_name="foods")
    category = models.ForeignKey(Category, on_delete=models.SET_NULL, null=True, blank=True)
    name = models.CharField(max_length=150)
    description = models.TextField(blank=True)
    price = models.DecimalField(max_digits=8, decimal_places=2)
    image = models.URLField(blank=True)
    is_available = models.BooleanField(default=True)
    def __str__(self): return self.name

class Order(models.Model):
    STATUS = [("Placed","Placed"),("Preparing","Preparing"),("Out for Delivery","Out for Delivery"),("Delivered","Delivered")]
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    address = models.TextField()
    total = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=30, choices=STATUS, default="Placed")
    created_at = models.DateTimeField(auto_now_add=True)
    def __str__(self): return f"Order #{self.id} - {self.user.username}"

class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="items")
    food = models.ForeignKey(Food, on_delete=models.PROTECT)
    quantity = models.PositiveIntegerField()
    price = models.DecimalField(max_digits=8, decimal_places=2)
    def subtotal(self): return self.quantity * self.price
