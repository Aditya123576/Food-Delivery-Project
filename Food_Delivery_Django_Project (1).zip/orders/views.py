from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.db.models import Q
from .models import Category, Restaurant, Food, Order, OrderItem

def home(request):
    q = request.GET.get("q","").strip()
    category = request.GET.get("category","")
    foods = Food.objects.filter(is_available=True).select_related("restaurant","category")
    if q:
        foods = foods.filter(Q(name__icontains=q)|Q(restaurant__name__icontains=q)|Q(category__name__icontains=q))
    if category:
        foods = foods.filter(category_id=category)
    return render(request,"home.html",{"foods":foods,"categories":Category.objects.all(),"restaurants":Restaurant.objects.all()})

def food_detail(request, food_id):
    return render(request,"food_detail.html",{"food":get_object_or_404(Food,id=food_id)})

def _cart(request):
    return request.session.setdefault("cart", {})

def add_to_cart(request, food_id):
    food=get_object_or_404(Food,id=food_id,is_available=True)
    cart=_cart(request); key=str(food_id)
    cart[key]=int(cart.get(key,0))+1
    request.session.modified=True
    return redirect("cart")

def remove_from_cart(request, food_id):
    cart=_cart(request); cart.pop(str(food_id),None); request.session.modified=True
    return redirect("cart")

def update_cart(request, food_id):
    qty=max(1,int(request.POST.get("quantity",1)))
    cart=_cart(request); cart[str(food_id)]=qty; request.session.modified=True
    return redirect("cart")

def cart(request):
    cart=_cart(request); items=[]; total=0
    for fid,qty in cart.items():
        food=get_object_or_404(Food,id=fid)
        subtotal=food.price*qty; total+=subtotal
        items.append({"food":food,"quantity":qty,"subtotal":subtotal})
    return render(request,"cart.html",{"items":items,"total":total})

@login_required
def checkout(request):
    cart=_cart(request)
    if not cart: return redirect("cart")
    items=[]; total=0
    for fid,qty in cart.items():
        food=get_object_or_404(Food,id=fid)
        total += food.price*qty
        items.append((food,qty))
    if request.method=="POST":
        address=request.POST.get("address","").strip()
        if address:
            order=Order.objects.create(user=request.user,address=address,total=total)
            for food,qty in items:
                OrderItem.objects.create(order=order,food=food,quantity=qty,price=food.price)
            request.session["cart"]={}; request.session.modified=True
            return redirect("orders")
    return render(request,"checkout.html",{"items":items,"total":total})

@login_required
def orders(request):
    return render(request,"orders.html",{"orders":Order.objects.filter(user=request.user).prefetch_related("items__food")})

def register(request):
    if request.method=="POST":
        form=UserCreationForm(request.POST)
        if form.is_valid():
            user=form.save(); login(request,user); return redirect("home")
    else: form=UserCreationForm()
    return render(request,"register.html",{"form":form})
